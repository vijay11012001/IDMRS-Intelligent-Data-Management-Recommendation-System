package com.idmrs.inventory.service;

import com.idmrs.inventory.dto.request.LoginRequest;
import com.idmrs.inventory.dto.request.RegisterRequest;
import com.idmrs.inventory.dto.response.AuthResponse;
import com.idmrs.inventory.entity.User;
import com.idmrs.inventory.exception.DuplicateResourceException;
import com.idmrs.inventory.repository.UserRepository;
import com.idmrs.inventory.security.JwtTokenProvider;
import com.idmrs.inventory.service.impl.AuthServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private AuthenticationManager authenticationManager;
    @Mock
    private JwtTokenProvider jwtTokenProvider;

    @InjectMocks
    private AuthServiceImpl authService;

    private RegisterRequest registerRequest;

    @BeforeEach
    void setUp() {
        registerRequest = new RegisterRequest();
        registerRequest.setUsername("testuser");
        registerRequest.setEmail("test@example.com");
        registerRequest.setPassword("Password@123");
        registerRequest.setFullName("Test User");
    }

    @Test
    void register_WithValidData_ShouldReturnAuthResponse() {
        when(userRepository.existsByUsername("testuser")).thenReturn(false);
        when(userRepository.existsByEmail("test@example.com")).thenReturn(false);
        when(passwordEncoder.encode(any())).thenReturn("encodedPassword");
        when(jwtTokenProvider.generateTokenFromUsername("testuser")).thenReturn("jwt_token");
        when(jwtTokenProvider.getExpirationMs()).thenReturn(86400000L);

        User savedUser = User.builder()
            .id(1L).username("testuser").email("test@example.com")
            .fullName("Test User").role(User.Role.USER).enabled(true).build();
        when(userRepository.save(any(User.class))).thenReturn(savedUser);

        AuthResponse response = authService.register(registerRequest);

        assertThat(response).isNotNull();
        assertThat(response.getUsername()).isEqualTo("testuser");
        assertThat(response.getAccessToken()).isEqualTo("jwt_token");
        assertThat(response.getRole()).isEqualTo("USER");
        verify(userRepository).save(any(User.class));
    }

    @Test
    void register_WithDuplicateUsername_ShouldThrowException() {
        when(userRepository.existsByUsername("testuser")).thenReturn(true);

        assertThatThrownBy(() -> authService.register(registerRequest))
            .isInstanceOf(DuplicateResourceException.class)
            .hasMessageContaining("testuser");

        verify(userRepository, never()).save(any());
    }

    @Test
    void register_WithDuplicateEmail_ShouldThrowException() {
        when(userRepository.existsByUsername("testuser")).thenReturn(false);
        when(userRepository.existsByEmail("test@example.com")).thenReturn(true);

        assertThatThrownBy(() -> authService.register(registerRequest))
            .isInstanceOf(DuplicateResourceException.class)
            .hasMessageContaining("test@example.com");
    }

    @Test
    void login_WithValidCredentials_ShouldReturnToken() {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("testuser");
        loginRequest.setPassword("Password@123");

        Authentication auth = mock(Authentication.class);
        User user = User.builder().id(1L).username("testuser").email("test@example.com")
            .fullName("Test User").role(User.Role.USER).enabled(true).build();

        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class))).thenReturn(auth);
        when(jwtTokenProvider.generateToken(auth)).thenReturn("login_jwt_token");
        when(jwtTokenProvider.getExpirationMs()).thenReturn(86400000L);
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));

        AuthResponse response = authService.login(loginRequest);

        assertThat(response.getAccessToken()).isEqualTo("login_jwt_token");
        assertThat(response.getUsername()).isEqualTo("testuser");
    }
}
