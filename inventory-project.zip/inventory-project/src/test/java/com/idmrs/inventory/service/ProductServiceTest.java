package com.idmrs.inventory.service;

import com.idmrs.inventory.dto.request.ProductRequest;
import com.idmrs.inventory.dto.response.ProductResponse;
import com.idmrs.inventory.entity.Product;
import com.idmrs.inventory.entity.User;
import com.idmrs.inventory.exception.DuplicateResourceException;
import com.idmrs.inventory.exception.ResourceNotFoundException;
import com.idmrs.inventory.intelligence.AlertEngine;
import com.idmrs.inventory.repository.ProductRepository;
import com.idmrs.inventory.repository.StockMovementRepository;
import com.idmrs.inventory.repository.UserRepository;
import com.idmrs.inventory.service.impl.ProductServiceImpl;
import com.idmrs.inventory.util.ProductMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private StockMovementRepository stockMovementRepository;
    @Mock
    private AlertEngine alertEngine;
    @Mock
    private ProductMapper productMapper;

    @InjectMocks
    private ProductServiceImpl productService;

    private User testUser;
    private ProductRequest productRequest;
    private Product testProduct;
    private ProductResponse testProductResponse;

    @BeforeEach
    void setUp() {
        testUser = User.builder().id(1L).username("admin").role(User.Role.ADMIN).build();

        productRequest = new ProductRequest();
        productRequest.setName("Test Product");
        productRequest.setSku("TEST-001");
        productRequest.setCategory(Product.Category.ELECTRONICS);
        productRequest.setPrice(new BigDecimal("99.99"));
        productRequest.setQuantity(50);
        productRequest.setReorderLevel(10);
        productRequest.setMaxStockLevel(100);

        testProduct = Product.builder()
            .id(1L).name("Test Product").sku("TEST-001")
            .category(Product.Category.ELECTRONICS).price(new BigDecimal("99.99"))
            .quantity(50).reorderLevel(10).maxStockLevel(100).createdBy(testUser).build();

        testProductResponse = ProductResponse.builder()
            .id(1L).name("Test Product").sku("TEST-001")
            .stockStatus("NORMAL").build();
    }

    @Test
    void createProduct_WithValidData_ShouldReturnProductResponse() {
        when(productRepository.existsBySku("TEST-001")).thenReturn(false);
        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(testUser));
        when(productMapper.toEntity(any(), any())).thenReturn(testProduct);
        when(productRepository.save(any())).thenReturn(testProduct);
        when(productMapper.toResponse(testProduct)).thenReturn(testProductResponse);

        ProductResponse response = productService.createProduct(productRequest, "admin");

        assertThat(response).isNotNull();
        assertThat(response.getName()).isEqualTo("Test Product");
        verify(alertEngine).evaluateProduct(testProduct);
    }

    @Test
    void createProduct_WithDuplicateSku_ShouldThrowException() {
        when(productRepository.existsBySku("TEST-001")).thenReturn(true);

        assertThatThrownBy(() -> productService.createProduct(productRequest, "admin"))
            .isInstanceOf(DuplicateResourceException.class)
            .hasMessageContaining("TEST-001");
    }

    @Test
    void getProductById_WhenExists_ShouldReturnResponse() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(testProduct));
        when(productMapper.toResponse(testProduct)).thenReturn(testProductResponse);

        ProductResponse response = productService.getProductById(1L);

        assertThat(response.getId()).isEqualTo(1L);
    }

    @Test
    void getProductById_WhenNotExists_ShouldThrowException() {
        when(productRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> productService.getProductById(99L))
            .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void getAllProducts_ShouldReturnPagedResults() {
        Page<Product> productPage = new PageImpl<>(List.of(testProduct));
        when(productRepository.findAll(any(PageRequest.class))).thenReturn(productPage);
        when(productMapper.toResponse(any())).thenReturn(testProductResponse);

        Page<ProductResponse> result = productService.getAllProducts(PageRequest.of(0, 10));

        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getName()).isEqualTo("Test Product");
    }

    @Test
    void deleteProduct_WhenExists_ShouldDelete() {
        when(productRepository.existsById(1L)).thenReturn(true);
        doNothing().when(productRepository).deleteById(1L);

        assertThatCode(() -> productService.deleteProduct(1L)).doesNotThrowAnyException();
        verify(productRepository).deleteById(1L);
    }

    @Test
    void deleteProduct_WhenNotExists_ShouldThrowException() {
        when(productRepository.existsById(99L)).thenReturn(false);

        assertThatThrownBy(() -> productService.deleteProduct(99L))
            .isInstanceOf(ResourceNotFoundException.class);
    }
}
