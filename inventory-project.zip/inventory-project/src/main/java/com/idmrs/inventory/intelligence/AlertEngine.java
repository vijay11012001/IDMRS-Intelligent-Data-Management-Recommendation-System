package com.idmrs.inventory.intelligence;

import com.idmrs.inventory.entity.Alert;
import com.idmrs.inventory.entity.Alert.AlertType;
import com.idmrs.inventory.entity.Alert.Severity;
import com.idmrs.inventory.entity.Product;
import com.idmrs.inventory.repository.AlertRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Rule-Based Intelligence Engine (Option C)
 *
 * Rules:
 * 1. LOW_STOCK:      quantity <= reorderLevel
 * 2. OUT_OF_STOCK:   quantity == 0
 * 3. OVERSTOCK:      quantity > maxStockLevel
 * 4. EXPIRY_WARNING: expiryDate within 30 days
 * 5. EXPIRED:        expiryDate in the past
 *
 * Severity mapping based on threshold percentages.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class AlertEngine {

    private final AlertRepository alertRepository;

    private static final int EXPIRY_WARNING_DAYS = 30;

    @Transactional
    public void evaluateProduct(Product product) {
        evaluateOutOfStock(product);
        evaluateLowStock(product);
        evaluateOverstock(product);
        evaluateExpiry(product);
        log.debug("Alert evaluation complete for product: {} [SKU: {}]", product.getName(), product.getSku());
    }

    private void evaluateOutOfStock(Product product) {
        if (product.getQuantity() == 0) {
            createAlertIfNotExists(product, AlertType.OUT_OF_STOCK, Severity.CRITICAL,
                String.format("CRITICAL: Product '%s' [SKU: %s] is OUT OF STOCK. Immediate reorder required.",
                    product.getName(), product.getSku()));
        } else {
            // Resolve out-of-stock if restocked
            resolveAlerts(product, AlertType.OUT_OF_STOCK);
        }
    }

    private void evaluateLowStock(Product product) {
        if (product.getQuantity() > 0 && product.getQuantity() <= product.getReorderLevel()) {
            double percentage = (double) product.getQuantity() / product.getReorderLevel() * 100;
            Severity severity = percentage <= 25 ? Severity.HIGH :
                                percentage <= 50 ? Severity.MEDIUM : Severity.LOW;

            createAlertIfNotExists(product, AlertType.LOW_STOCK, severity,
                String.format("LOW STOCK: '%s' [SKU: %s] has only %d units (reorder level: %d). Consider restocking.",
                    product.getName(), product.getSku(), product.getQuantity(), product.getReorderLevel()));
        } else {
            resolveAlerts(product, AlertType.LOW_STOCK);
        }
    }

    private void evaluateOverstock(Product product) {
        if (product.getQuantity() > product.getMaxStockLevel()) {
            double excess = (double) (product.getQuantity() - product.getMaxStockLevel()) / product.getMaxStockLevel() * 100;
            Severity severity = excess >= 50 ? Severity.HIGH : excess >= 25 ? Severity.MEDIUM : Severity.LOW;

            createAlertIfNotExists(product, AlertType.OVERSTOCK, severity,
                String.format("OVERSTOCK: '%s' [SKU: %s] has %d units, exceeding max level of %d. Consider promotions.",
                    product.getName(), product.getSku(), product.getQuantity(), product.getMaxStockLevel()));
        } else {
            resolveAlerts(product, AlertType.OVERSTOCK);
        }
    }

    private void evaluateExpiry(Product product) {
        if (product.getExpiryDate() == null) return;

        LocalDate today = LocalDate.now();
        if (product.getExpiryDate().isBefore(today)) {
            createAlertIfNotExists(product, AlertType.EXPIRED, Severity.CRITICAL,
                String.format("EXPIRED: Product '%s' [SKU: %s] expired on %s. Remove from inventory immediately.",
                    product.getName(), product.getSku(), product.getExpiryDate()));
        } else if (product.getExpiryDate().isBefore(today.plusDays(EXPIRY_WARNING_DAYS))) {
            long daysLeft = ChronoUnit.DAYS.between(today, product.getExpiryDate());
            Severity severity = daysLeft <= 7 ? Severity.HIGH : daysLeft <= 15 ? Severity.MEDIUM : Severity.LOW;
            createAlertIfNotExists(product, AlertType.EXPIRY_WARNING, severity,
                String.format("EXPIRY WARNING: '%s' [SKU: %s] expires in %d days on %s.",
                    product.getName(), product.getSku(), daysLeft, product.getExpiryDate()));
        } else {
            resolveAlerts(product, AlertType.EXPIRY_WARNING);
        }
    }

    private void createAlertIfNotExists(Product product, AlertType type, Severity severity, String message) {
        boolean exists = alertRepository.existsByProductIdAndAlertTypeAndResolvedFalse(product.getId(), type);
        if (!exists) {
            Alert alert = Alert.builder()
                .product(product)
                .alertType(type)
                .severity(severity)
                .message(message)
                .resolved(false)
                .build();
            alertRepository.save(alert);
            log.warn("Alert created - Type: {} | Severity: {} | Product: {}", type, severity, product.getSku());
        }
    }

    private void resolveAlerts(Product product, AlertType type) {
        List<Alert> activeAlerts = alertRepository.findByProductIdAndResolvedFalse(product.getId())
            .stream()
            .filter(a -> a.getAlertType() == type)
            .toList();

        activeAlerts.forEach(alert -> {
            alert.setResolved(true);
            alert.setResolvedAt(java.time.LocalDateTime.now());
            alertRepository.save(alert);
            log.info("Alert auto-resolved - Type: {} | Product: {}", type, product.getSku());
        });
    }

}
