package com.idmrs.inventory.service;

import com.idmrs.inventory.dto.request.ProductRequest;
import com.idmrs.inventory.dto.response.ProductResponse;
import com.idmrs.inventory.entity.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface ProductService {
    ProductResponse createProduct(ProductRequest request, String username);
    ProductResponse updateProduct(Long id, ProductRequest request);
    ProductResponse getProductById(Long id);
    ProductResponse getProductBySku(String sku);
    Page<ProductResponse> getAllProducts(Pageable pageable);
    Page<ProductResponse> getProductsByCategory(Product.Category category, Pageable pageable);
    Page<ProductResponse> searchProducts(String keyword, Pageable pageable);
    void deleteProduct(Long id);
    List<ProductResponse> importFromCsv(MultipartFile file, String username);
    Map<String, Object> getDashboardStats();
    void evictProductCache();
}
