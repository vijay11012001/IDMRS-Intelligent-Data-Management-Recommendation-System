package com.idmrs.inventory.config;

import com.idmrs.inventory.entity.User;
import com.idmrs.inventory.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Create default admin account if not exists
        if (!userRepository.existsByUsername("admin")) {
            User admin = User.builder()
                .username("admin")
                .email("admin@idmrs.com")
                .password(passwordEncoder.encode("Admin@123"))
                .fullName("System Administrator")
                .role(User.Role.ADMIN)
                .enabled(true)
                .build();
            userRepository.save(admin);
            log.info("Default admin account created: username=admin, password=Admin@123");
        }

        // Create default test user if not exists
        if (!userRepository.existsByUsername("user")) {
            User user = User.builder()
                .username("user")
                .email("user@idmrs.com")
                .password(passwordEncoder.encode("User@123"))
                .fullName("Test User")
                .role(User.Role.USER)
                .enabled(true)
                .build();
            userRepository.save(user);
            log.info("Default test user created: username=user, password=User@123");
        }

        log.info("=== IDMRS Inventory System Started ===");
        log.info("Swagger UI: http://localhost:8080/api/swagger-ui.html");
        log.info("Default Admin: admin / Admin@123");
        log.info("Default User:  user  / User@123");
    }
}
