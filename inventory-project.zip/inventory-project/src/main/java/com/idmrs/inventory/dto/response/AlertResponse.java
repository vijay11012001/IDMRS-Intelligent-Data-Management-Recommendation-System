package com.idmrs.inventory.dto.response;

import com.idmrs.inventory.entity.Alert;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data @Builder
public class AlertResponse {
    private Long id;
    private Long productId;
    private String productName;
    private String productSku;
    private Alert.AlertType alertType;
    private Alert.Severity severity;
    private String message;
    private boolean resolved;
    private LocalDateTime resolvedAt;
    private String resolvedBy;
    private LocalDateTime createdAt;
}
