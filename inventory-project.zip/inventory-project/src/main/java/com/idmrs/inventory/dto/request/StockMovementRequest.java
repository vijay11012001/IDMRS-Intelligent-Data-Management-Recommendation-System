package com.idmrs.inventory.dto.request;

import com.idmrs.inventory.entity.StockMovement;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class StockMovementRequest {

    @NotNull(message = "Product ID is required")
    private Long productId;

    @NotNull(message = "Movement type is required")
    private StockMovement.MovementType movementType;

    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Quantity must be at least 1")
    private Integer quantity;

    @Size(max = 255, message = "Reason must not exceed 255 characters")
    private String reason;

    @Size(max = 100, message = "Reference must not exceed 100 characters")
    private String reference;
}
