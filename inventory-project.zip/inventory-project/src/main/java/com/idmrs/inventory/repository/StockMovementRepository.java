package com.idmrs.inventory.repository;

import com.idmrs.inventory.entity.StockMovement;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface StockMovementRepository extends JpaRepository<StockMovement, Long> {

    Page<StockMovement> findByProductId(Long productId, Pageable pageable);

    List<StockMovement> findByProductIdAndCreatedAtBetween(
        Long productId, LocalDateTime from, LocalDateTime to);

    @Query("SELECT sm.movementType, SUM(sm.quantity) FROM StockMovement sm " +
           "WHERE sm.product.id = :productId GROUP BY sm.movementType")
    List<Object[]> getMovementSummaryByProduct(@Param("productId") Long productId);

    @Query("SELECT sm FROM StockMovement sm WHERE sm.createdAt >= :since ORDER BY sm.createdAt DESC")
    List<StockMovement> findRecentMovements(@Param("since") LocalDateTime since);
}
