package com.idmrs.inventory.service.impl;

import com.idmrs.inventory.dto.response.AlertResponse;
import com.idmrs.inventory.entity.Alert;
import com.idmrs.inventory.entity.User;
import com.idmrs.inventory.exception.ResourceNotFoundException;
import com.idmrs.inventory.repository.AlertRepository;
import com.idmrs.inventory.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class AlertService {

    private final AlertRepository alertRepository;
    private final UserRepository userRepository;

    @Cacheable(value = "alerts", key = "'active-' + #pageable.pageNumber")
    @Transactional(readOnly = true)
    public Page<AlertResponse> getActiveAlerts(Pageable pageable) {
        return alertRepository.findByResolved(false, pageable).map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public Page<AlertResponse> getAllAlerts(boolean resolved, Pageable pageable) {
        return alertRepository.findByResolved(resolved, pageable).map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public List<AlertResponse> getPriorityAlerts() {
        return alertRepository.findActiveAlertsBySeverity()
            .stream().map(this::toResponse).toList();
    }

    @Transactional
    @CacheEvict(value = "alerts", allEntries = true)
    public AlertResponse resolveAlert(Long alertId, String username) {
        Alert alert = alertRepository.findById(alertId)
            .orElseThrow(() -> new ResourceNotFoundException("Alert", "id", alertId));

        if (alert.isResolved()) {
            throw new IllegalArgumentException("Alert is already resolved");
        }

        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("User: " + username));

        alert.setResolved(true);
        alert.setResolvedAt(LocalDateTime.now());
        alert.setResolvedBy(user);
        Alert saved = alertRepository.save(alert);

        log.info("Alert {} resolved by {}", alertId, username);
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public Map<String, Long> getAlertSummary() {
        return Map.of(
            "critical", alertRepository.countActiveAlertsBySeverity(Alert.Severity.CRITICAL),
            "high", alertRepository.countActiveAlertsBySeverity(Alert.Severity.HIGH),
            "medium", alertRepository.countActiveAlertsBySeverity(Alert.Severity.MEDIUM),
            "low", alertRepository.countActiveAlertsBySeverity(Alert.Severity.LOW),
            "total", alertRepository.findByResolved(false, Pageable.unpaged()).getTotalElements()
        );
    }

    private AlertResponse toResponse(Alert alert) {
        return AlertResponse.builder()
            .id(alert.getId())
            .productId(alert.getProduct().getId())
            .productName(alert.getProduct().getName())
            .productSku(alert.getProduct().getSku())
            .alertType(alert.getAlertType())
            .severity(alert.getSeverity())
            .message(alert.getMessage())
            .resolved(alert.isResolved())
            .resolvedAt(alert.getResolvedAt())
            .resolvedBy(alert.getResolvedBy() != null ? alert.getResolvedBy().getUsername() : null)
            .createdAt(alert.getCreatedAt())
            .build();
    }
}
