package com.idmrs.inventory.service.impl;

import com.idmrs.inventory.dto.request.StockMovementRequest;
import com.idmrs.inventory.dto.response.StockMovementResponse;
import com.idmrs.inventory.entity.Product;
import com.idmrs.inventory.entity.StockMovement;
import com.idmrs.inventory.entity.User;
import com.idmrs.inventory.exception.InsufficientStockException;
import com.idmrs.inventory.exception.ResourceNotFoundException;
import com.idmrs.inventory.intelligence.AlertEngine;
import com.idmrs.inventory.repository.ProductRepository;
import com.idmrs.inventory.repository.StockMovementRepository;
import com.idmrs.inventory.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class StockMovementService {

    private final StockMovementRepository stockMovementRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final AlertEngine alertEngine;

    @Transactional
    @CacheEvict(value = {"products", "productById", "dashboardStats"}, allEntries = true)
    public StockMovementResponse recordMovement(StockMovementRequest request, String username) {
        Product product = productRepository.findById(request.getProductId())
            .orElseThrow(() -> new ResourceNotFoundException("Product", "id", request.getProductId()));

        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        // Update quantity based on movement type
        int newQuantity = calculateNewQuantity(product, request);
        if (newQuantity < 0) {
            throw new InsufficientStockException(
                String.format("Insufficient stock. Available: %d, Requested: %d",
                    product.getQuantity(), request.getQuantity()));
        }
        product.setQuantity(newQuantity);
        Product savedProduct = productRepository.save(product);

        StockMovement movement = StockMovement.builder()
            .product(savedProduct)
            .movementType(request.getMovementType())
            .quantity(request.getQuantity())
            .reason(request.getReason())
            .reference(request.getReference())
            .performedBy(user)
            .build();
        StockMovement saved = stockMovementRepository.save(movement);

        // Re-evaluate alerts after stock change
        alertEngine.evaluateProduct(savedProduct);

        log.info("Stock movement: {} {} units of {} by {}",
            request.getMovementType(), request.getQuantity(), product.getSku(), username);

        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public Page<StockMovementResponse> getMovementsByProduct(Long productId, Pageable pageable) {
        if (!productRepository.existsById(productId)) {
            throw new ResourceNotFoundException("Product", "id", productId);
        }
        return stockMovementRepository.findByProductId(productId, pageable).map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public Page<StockMovementResponse> getAllMovements(Pageable pageable) {
        return stockMovementRepository.findAll(pageable).map(this::toResponse);
    }

    private int calculateNewQuantity(Product product, StockMovementRequest request) {
        return switch (request.getMovementType()) {
            case IN, RETURN -> product.getQuantity() + request.getQuantity();
            case OUT, DAMAGE -> product.getQuantity() - request.getQuantity();
            case ADJUSTMENT -> request.getQuantity(); // Direct set
        };
    }

    private StockMovementResponse toResponse(StockMovement m) {
        return StockMovementResponse.builder()
            .id(m.getId())
            .productId(m.getProduct().getId())
            .productName(m.getProduct().getName())
            .productSku(m.getProduct().getSku())
            .movementType(m.getMovementType())
            .quantity(m.getQuantity())
            .unitPrice(m.getUnitPrice())
            .reason(m.getReason())
            .reference(m.getReference())
            .performedBy(m.getPerformedBy().getUsername())
            .createdAt(m.getCreatedAt())
            .build();
    }
}
