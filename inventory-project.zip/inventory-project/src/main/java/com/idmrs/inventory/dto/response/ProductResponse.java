package com.idmrs.inventory.dto.response;

import com.idmrs.inventory.entity.Product;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @Builder
public class ProductResponse {
    private Long id;
    private String name;
    private String sku;
    private String description;
    private Product.Category category;
    private BigDecimal price;
    private Integer quantity;
    private Integer reorderLevel;
    private Integer maxStockLevel;
    private String supplier;
    private LocalDate expiryDate;
    private String imageUrl;
    private String createdBy;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String stockStatus;
    private boolean lowStockAlert;
    private boolean overstockAlert;
    private boolean expiryAlert;
}
