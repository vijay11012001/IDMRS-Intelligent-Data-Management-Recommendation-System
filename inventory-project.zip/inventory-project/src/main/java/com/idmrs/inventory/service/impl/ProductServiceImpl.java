package com.idmrs.inventory.service.impl;

import com.idmrs.inventory.dto.request.ProductRequest;
import com.idmrs.inventory.dto.response.ProductResponse;
import com.idmrs.inventory.entity.Product;
import com.idmrs.inventory.entity.User;
import com.idmrs.inventory.exception.DuplicateResourceException;
import com.idmrs.inventory.exception.ResourceNotFoundException;
import com.idmrs.inventory.intelligence.AlertEngine;
import com.idmrs.inventory.repository.ProductRepository;
import com.idmrs.inventory.repository.StockMovementRepository;
import com.idmrs.inventory.repository.UserRepository;
import com.idmrs.inventory.service.ProductService;
import com.idmrs.inventory.util.ProductMapper;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final StockMovementRepository stockMovementRepository;
    private final AlertEngine alertEngine;
    private final ProductMapper productMapper;

    @Override
    @Transactional
    @CacheEvict(value = {"products", "dashboardStats", "categoryStats"}, allEntries = true)
    public ProductResponse createProduct(ProductRequest request, String username) {
        if (productRepository.existsBySku(request.getSku())) {
            throw new DuplicateResourceException("Product with SKU '" + request.getSku() + "' already exists");
        }
        if (request.getMaxStockLevel() <= request.getReorderLevel()) {
            throw new IllegalArgumentException("Max stock level must be greater than reorder level");
        }

        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        Product product = productMapper.toEntity(request, user);
        Product saved = productRepository.save(product);

        // Run intelligence engine
        alertEngine.evaluateProduct(saved);

        log.info("Product created: {} [SKU: {}] by {}", saved.getName(), saved.getSku(), username);
        return productMapper.toResponse(saved);
    }

    @Override
    @Transactional
    @CacheEvict(value = {"products", "productById", "dashboardStats", "categoryStats"}, allEntries = true)
    public ProductResponse updateProduct(Long id, ProductRequest request) {
        Product existing = productRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));

        if (!existing.getSku().equals(request.getSku()) && productRepository.existsBySku(request.getSku())) {
            throw new DuplicateResourceException("Product with SKU '" + request.getSku() + "' already exists");
        }

        productMapper.updateEntity(existing, request);
        Product updated = productRepository.save(existing);

        alertEngine.evaluateProduct(updated);

        log.info("Product updated: {} [ID: {}]", updated.getName(), id);
        return productMapper.toResponse(updated);
    }

    @Override
    @Cacheable(value = "productById", key = "#id")
    @Transactional(readOnly = true)
    public ProductResponse getProductById(Long id) {
        Product product = productRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));
        return productMapper.toResponse(product);
    }

    @Override
    @Transactional(readOnly = true)
    public ProductResponse getProductBySku(String sku) {
        Product product = productRepository.findBySku(sku)
            .orElseThrow(() -> new ResourceNotFoundException("Product", "SKU", sku));
        return productMapper.toResponse(product);
    }

    @Override
    @Cacheable(value = "products", key = "#pageable.pageNumber + '-' + #pageable.pageSize + '-' + #pageable.sort")
    @Transactional(readOnly = true)
    public Page<ProductResponse> getAllProducts(Pageable pageable) {
        return productRepository.findAll(pageable).map(productMapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> getProductsByCategory(Product.Category category, Pageable pageable) {
        return productRepository.findByCategory(category, pageable).map(productMapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ProductResponse> searchProducts(String keyword, Pageable pageable) {
        return productRepository.searchByKeyword(keyword, pageable).map(productMapper::toResponse);
    }

    @Override
    @Transactional
    @CacheEvict(value = {"products", "productById", "dashboardStats", "categoryStats"}, allEntries = true)
    public void deleteProduct(Long id) {
        if (!productRepository.existsById(id)) {
            throw new ResourceNotFoundException("Product", "id", id);
        }
        productRepository.deleteById(id);
        log.info("Product deleted: ID {}", id);
    }

    @Override
    @Transactional
    @CacheEvict(value = {"products", "dashboardStats", "categoryStats"}, allEntries = true)
    public List<ProductResponse> importFromCsv(MultipartFile file, String username) {
        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        if (file.isEmpty()) {
            throw new IllegalArgumentException("CSV file is empty");
        }
        validateCsvContentType(file);

        List<ProductResponse> imported = new ArrayList<>();
        List<String> errors = new ArrayList<>();

        try (CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream()))) {
            List<String[]> rows = reader.readAll();
            if (rows.size() < 2) {
                throw new IllegalArgumentException("CSV must have at least one data row after header");
            }

            for (int i = 1; i < rows.size(); i++) {
                String[] row = rows.get(i);
                try {
                    Product product = parseCsvRow(row, user);
                    if (productRepository.existsBySku(product.getSku())) {
                        errors.add("Row " + (i + 1) + ": SKU '" + product.getSku() + "' already exists - skipped");
                        continue;
                    }
                    Product saved = productRepository.save(product);
                    alertEngine.evaluateProduct(saved);
                    imported.add(productMapper.toResponse(saved));
                } catch (Exception e) {
                    errors.add("Row " + (i + 1) + ": " + e.getMessage());
                }
            }
        } catch (IOException | CsvException e) {
            throw new IllegalArgumentException("Failed to parse CSV file: " + e.getMessage());
        }

        log.info("CSV import complete: {} products imported, {} errors by {}", imported.size(), errors.size(), username);
        if (!errors.isEmpty()) {
            log.warn("CSV import errors: {}", errors);
        }
        return imported;
    }

    @Override
    @Cacheable(value = "dashboardStats")
    @Transactional(readOnly = true)
    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalProducts", productRepository.count());
        stats.put("lowStockCount", productRepository.findLowStockProducts().size());
        stats.put("outOfStockCount", productRepository.findOutOfStockProducts().size());
        stats.put("overstockCount", productRepository.findOverstockProducts().size());
        stats.put("expiringIn30Days", productRepository
            .findExpiringProducts(LocalDate.now().plusDays(30)).size());
        stats.put("categoryStats", getCategoryBreakdown());
        return stats;
    }

    @Override
    @CacheEvict(value = {"products", "productById", "dashboardStats", "categoryStats"}, allEntries = true)
    public void evictProductCache() {
        log.debug("Product cache evicted");
    }

    private Map<String, Object> getCategoryBreakdown() {
        Map<String, Object> categoryMap = new LinkedHashMap<>();
        productRepository.getCategoryStats().forEach(row -> {
            Map<String, Object> cat = new HashMap<>();
            cat.put("count", row[1]);
            cat.put("totalQuantity", row[2]);
            categoryMap.put(row[0].toString(), cat);
        });
        return categoryMap;
    }

    private void validateCsvContentType(MultipartFile file) {
        String contentType = file.getContentType();
        String filename = file.getOriginalFilename();
        if (contentType == null || (!contentType.contains("csv") && !contentType.contains("text/plain"))) {
            if (filename == null || !filename.toLowerCase().endsWith(".csv")) {
                throw new IllegalArgumentException("Only CSV files are allowed");
            }
        }
    }

    private Product parseCsvRow(String[] row, User user) {
        // Expected columns: name, sku, category, price, quantity, reorderLevel, maxStockLevel, supplier, description
        if (row.length < 7) {
            throw new IllegalArgumentException("Invalid CSV format. Expected at least 7 columns");
        }
        return Product.builder()
            .name(row[0].trim())
            .sku(row[1].trim().toUpperCase())
            .category(Product.Category.valueOf(row[2].trim().toUpperCase()))
            .price(new BigDecimal(row[3].trim()))
            .quantity(Integer.parseInt(row[4].trim()))
            .reorderLevel(Integer.parseInt(row[5].trim()))
            .maxStockLevel(Integer.parseInt(row[6].trim()))
            .supplier(row.length > 7 ? row[7].trim() : null)
            .description(row.length > 8 ? row[8].trim() : null)
            .createdBy(user)
            .build();
    }
}
