package com.idmrs.inventory.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("IDMRS - Inventory Management API")
                .description("""
                    **Intelligent Data Management & Recommendation System**
                    
                    A production-ready REST API for inventory management with:
                    - JWT-based Authentication & Authorization
                    - Role-Based Access Control (Admin/User)
                    - Full CRUD for Products & Stock Management
                    - Intelligent Rule-Based Alert System
                    - CSV Bulk Import
                    - In-Memory Caching
                    - Rate Limiting
                    """)
                .version("1.0.0")
                .contact(new Contact()
                    .name("IDMRS Team")
                    .email("admin@idmrs.com"))
                .license(new License()
                    .name("Apache 2.0")
                    .url("https://www.apache.org/licenses/LICENSE-2.0")))
            .addSecurityItem(new SecurityRequirement().addList("Bearer Authentication"))
            .components(new Components()
                .addSecuritySchemes("Bearer Authentication",
                    new SecurityScheme()
                        .type(SecurityScheme.Type.HTTP)
                        .scheme("bearer")
                        .bearerFormat("JWT")
                        .description("Enter JWT token (without 'Bearer ' prefix)")));
    }
}
