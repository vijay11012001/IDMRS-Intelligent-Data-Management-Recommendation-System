package com.idmrs.inventory.controller;

import com.idmrs.inventory.dto.request.StockMovementRequest;
import com.idmrs.inventory.dto.response.ApiResponse;
import com.idmrs.inventory.dto.response.StockMovementResponse;
import com.idmrs.inventory.service.impl.StockMovementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/stock-movements")
@RequiredArgsConstructor
@Tag(name = "Stock Movements", description = "Record stock IN/OUT/ADJUSTMENT/RETURN/DAMAGE")
@SecurityRequirement(name = "Bearer Authentication")
public class StockMovementController {

    private final StockMovementService stockMovementService;

    @PostMapping
    @Operation(summary = "Record a stock movement")
    public ResponseEntity<ApiResponse<StockMovementResponse>> recordMovement(
            @Valid @RequestBody StockMovementRequest request,
            Authentication auth) {
        StockMovementResponse response = stockMovementService.recordMovement(request, auth.getName());
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success(response, "Stock movement recorded successfully"));
    }

    @GetMapping
    @Operation(summary = "Get all stock movements with pagination")
    public ResponseEntity<ApiResponse<Page<StockMovementResponse>>> getAllMovements(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sort = direction.equalsIgnoreCase("asc") ?
            Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return ResponseEntity.ok(ApiResponse.success(stockMovementService.getAllMovements(pageable)));
    }

    @GetMapping("/product/{productId}")
    @Operation(summary = "Get stock movements for a specific product")
    public ResponseEntity<ApiResponse<Page<StockMovementResponse>>> getMovementsByProduct(
            @PathVariable Long productId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return ResponseEntity.ok(ApiResponse.success(
            stockMovementService.getMovementsByProduct(productId, pageable)));
    }
}
