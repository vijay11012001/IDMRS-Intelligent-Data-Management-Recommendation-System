package com.idmrs.inventory.util;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory rate limiter using Bucket4j.
 * Limits: 60 requests/minute per IP for general endpoints.
 *         10 requests/minute per IP for auth endpoints.
 */
@Component
public class RateLimiter {

    private final ConcurrentHashMap<String, Bucket> generalBuckets = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Bucket> authBuckets = new ConcurrentHashMap<>();

    public boolean tryConsume(String clientId, boolean isAuthEndpoint) {
        ConcurrentHashMap<String, Bucket> buckets = isAuthEndpoint ? authBuckets : generalBuckets;
        Bucket bucket = buckets.computeIfAbsent(clientId, k -> createBucket(isAuthEndpoint));
        return bucket.tryConsume(1);
    }

    private Bucket createBucket(boolean isAuthEndpoint) {
        long capacity = isAuthEndpoint ? 10L : 60L;
        Bandwidth limit = Bandwidth.builder()
            .capacity(capacity)
            .refillGreedy(capacity, Duration.ofMinutes(1))
            .build();
        return Bucket.builder().addLimit(limit).build();
    }

    public static String getClientIp(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
