package com.idmrs.inventory.util;

import com.idmrs.inventory.dto.request.ProductRequest;
import com.idmrs.inventory.dto.response.ProductResponse;
import com.idmrs.inventory.entity.Product;
import com.idmrs.inventory.entity.User;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class ProductMapper {

    public Product toEntity(ProductRequest request, User createdBy) {
        return Product.builder()
            .name(request.getName())
            .sku(request.getSku().toUpperCase())
            .description(request.getDescription())
            .category(request.getCategory())
            .price(request.getPrice())
            .quantity(request.getQuantity())
            .reorderLevel(request.getReorderLevel())
            .maxStockLevel(request.getMaxStockLevel())
            .supplier(request.getSupplier())
            .expiryDate(request.getExpiryDate())
            .createdBy(createdBy)
            .build();
    }

    public void updateEntity(Product product, ProductRequest request) {
        product.setName(request.getName());
        product.setSku(request.getSku().toUpperCase());
        product.setDescription(request.getDescription());
        product.setCategory(request.getCategory());
        product.setPrice(request.getPrice());
        product.setQuantity(request.getQuantity());
        product.setReorderLevel(request.getReorderLevel());
        product.setMaxStockLevel(request.getMaxStockLevel());
        product.setSupplier(request.getSupplier());
        product.setExpiryDate(request.getExpiryDate());
    }

    public ProductResponse toResponse(Product product) {
        boolean isLowStock = product.getQuantity() <= product.getReorderLevel();
        boolean isOverstock = product.getQuantity() > product.getMaxStockLevel();
        boolean isExpiring = product.getExpiryDate() != null &&
            product.getExpiryDate().isBefore(LocalDate.now().plusDays(30));

        String stockStatus;
        if (product.getQuantity() == 0) stockStatus = "OUT_OF_STOCK";
        else if (isLowStock) stockStatus = "LOW_STOCK";
        else if (isOverstock) stockStatus = "OVERSTOCK";
        else stockStatus = "NORMAL";

        return ProductResponse.builder()
            .id(product.getId())
            .name(product.getName())
            .sku(product.getSku())
            .description(product.getDescription())
            .category(product.getCategory())
            .price(product.getPrice())
            .quantity(product.getQuantity())
            .reorderLevel(product.getReorderLevel())
            .maxStockLevel(product.getMaxStockLevel())
            .supplier(product.getSupplier())
            .expiryDate(product.getExpiryDate())
            .imageUrl(product.getImageUrl())
            .createdBy(product.getCreatedBy() != null ? product.getCreatedBy().getUsername() : null)
            .createdAt(product.getCreatedAt())
            .updatedAt(product.getUpdatedAt())
            .stockStatus(stockStatus)
            .lowStockAlert(isLowStock)
            .overstockAlert(isOverstock)
            .expiryAlert(isExpiring)
            .build();
    }
}
