package com.idmrs.inventory.intelligence;

import com.idmrs.inventory.entity.Product;
import com.idmrs.inventory.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Scheduled service that runs periodic alert evaluations across all products.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class AlertSchedulerService {

    private final ProductRepository productRepository;
    private final AlertEngine alertEngine;

    @Scheduled(cron = "0 0 */6 * * *")
    @Transactional
    public void runPeriodicAlertCheck() {
        log.info("Starting scheduled product alert evaluation...");
        List<Product> allProducts = productRepository.findAll();
        int evaluated = 0;
        for (Product product : allProducts) {
            try {
                alertEngine.evaluateProduct(product);
                evaluated++;
            } catch (Exception e) {
                log.error("Error evaluating product {}: {}", product.getSku(), e.getMessage());
            }
        }
        log.info("Scheduled alert evaluation complete. Evaluated {} products.", evaluated);
    }
}
