package com.idmrs.inventory.service;

import com.idmrs.inventory.dto.request.LoginRequest;
import com.idmrs.inventory.dto.request.RegisterRequest;
import com.idmrs.inventory.dto.response.AuthResponse;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
}
