package com.idmrs.inventory.controller;

import com.idmrs.inventory.dto.response.ApiResponse;
import com.idmrs.inventory.entity.User;
import com.idmrs.inventory.repository.UserRepository;
import com.idmrs.inventory.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
@Tag(name = "Admin", description = "Admin-only operations")
@SecurityRequirement(name = "Bearer Authentication")
public class AdminController {

    private final UserRepository userRepository;
    private final ProductService productService;

    @GetMapping("/users")
    @Operation(summary = "List all registered users. ADMIN only.")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> getAllUsers() {
        List<Map<String, Object>> users = userRepository.findAll().stream()
            .map(u -> Map.<String, Object>of(
                "id", u.getId(),
                "username", u.getUsername(),
                "email", u.getEmail(),
                "fullName", u.getFullName(),
                "role", u.getRole().name(),
                "enabled", u.isEnabled(),
                "createdAt", u.getCreatedAt()
            ))
            .collect(Collectors.toList());
        return ResponseEntity.ok(ApiResponse.success(users, "All users retrieved"));
    }

    @PatchMapping("/users/{id}/role")
    @Operation(summary = "Change user role (ADMIN/USER). ADMIN only.")
    public ResponseEntity<ApiResponse<String>> changeUserRole(
            @PathVariable Long id,
            @RequestParam User.Role role) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new com.idmrs.inventory.exception.ResourceNotFoundException("User", "id", id));
        user.setRole(role);
        userRepository.save(user);
        return ResponseEntity.ok(ApiResponse.success(
            "Role updated to " + role.name(), "User role changed successfully"));
    }

    @PatchMapping("/users/{id}/toggle-status")
    @Operation(summary = "Enable or disable a user account. ADMIN only.")
    public ResponseEntity<ApiResponse<String>> toggleUserStatus(@PathVariable Long id) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new com.idmrs.inventory.exception.ResourceNotFoundException("User", "id", id));
        user.setEnabled(!user.isEnabled());
        userRepository.save(user);
        String status = user.isEnabled() ? "enabled" : "disabled";
        return ResponseEntity.ok(ApiResponse.success("User " + status, "User status changed"));
    }

    @PostMapping("/cache/clear")
    @Operation(summary = "Clear all application caches. ADMIN only.")
    public ResponseEntity<ApiResponse<String>> clearCache() {
        productService.evictProductCache();
        return ResponseEntity.ok(ApiResponse.success("All caches cleared", "Cache cleared"));
    }
}
