package com.idmrs.inventory.repository;

import com.idmrs.inventory.entity.Alert;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AlertRepository extends JpaRepository<Alert, Long> {

    Page<Alert> findByResolved(boolean resolved, Pageable pageable);

    List<Alert> findByProductIdAndResolvedFalse(Long productId);

    boolean existsByProductIdAndAlertTypeAndResolvedFalse(
        Long productId, Alert.AlertType alertType);

    @Query("SELECT a FROM Alert a WHERE a.resolved = false ORDER BY a.severity DESC, a.createdAt DESC")
    List<Alert> findActiveAlertsBySeverity();

    @Query("SELECT COUNT(a) FROM Alert a WHERE a.resolved = false AND a.severity = :severity")
    long countActiveAlertsBySeverity(@Param("severity") Alert.Severity severity);
}
