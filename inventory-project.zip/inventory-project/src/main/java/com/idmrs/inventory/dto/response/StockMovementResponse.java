package com.idmrs.inventory.dto.response;

import com.idmrs.inventory.entity.StockMovement;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data @Builder
public class StockMovementResponse {
    private Long id;
    private Long productId;
    private String productName;
    private String productSku;
    private StockMovement.MovementType movementType;
    private Integer quantity;
    private BigDecimal unitPrice;
    private String reason;
    private String reference;
    private String performedBy;
    private LocalDateTime createdAt;
}
