package com.idmrs.inventory.controller;

import com.idmrs.inventory.dto.response.AlertResponse;
import com.idmrs.inventory.dto.response.ApiResponse;
import com.idmrs.inventory.service.impl.AlertService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/alerts")
@RequiredArgsConstructor
@Tag(name = "Intelligent Alerts", description = "Rule-based alert system for inventory anomalies")
@SecurityRequirement(name = "Bearer Authentication")
public class AlertController {

    private final AlertService alertService;

    @GetMapping
    @Operation(summary = "Get all alerts (active or resolved)",
               description = "Returns paginated alerts. Default: active only")
    public ResponseEntity<ApiResponse<Page<AlertResponse>>> getAlerts(
            @RequestParam(defaultValue = "false") boolean resolved,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return ResponseEntity.ok(ApiResponse.success(alertService.getAllAlerts(resolved, pageable)));
    }

    @GetMapping("/priority")
    @Operation(summary = "Get active alerts sorted by severity (CRITICAL → LOW)")
    public ResponseEntity<ApiResponse<List<AlertResponse>>> getPriorityAlerts() {
        return ResponseEntity.ok(ApiResponse.success(alertService.getPriorityAlerts(),
            "Priority alerts"));
    }

    @GetMapping("/summary")
    @Operation(summary = "Get alert count summary by severity")
    public ResponseEntity<ApiResponse<Map<String, Long>>> getAlertSummary() {
        return ResponseEntity.ok(ApiResponse.success(alertService.getAlertSummary(), "Alert summary"));
    }

    @PatchMapping("/{id}/resolve")
    @Operation(summary = "Resolve an alert manually")
    public ResponseEntity<ApiResponse<AlertResponse>> resolveAlert(
            @PathVariable Long id,
            Authentication auth) {
        AlertResponse response = alertService.resolveAlert(id, auth.getName());
        return ResponseEntity.ok(ApiResponse.success(response, "Alert resolved successfully"));
    }
}
